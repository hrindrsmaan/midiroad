MidiRoad Free Starter Kit
=========================

12 royalty-free MIDI drum patterns from MidiRoad, two from each style.

How to use them
- Drag a .mid file onto a drum, hi-hat or 808 channel in FL Studio, Ableton Live,
  Logic Pro or any DAW. Set your project to the BPM in the file name.
- 808 files are written in C. Load your 808 sample and transpose to your key.

License
- Royalty-free: use these patterns in your beats and released music.
- Do not resell or share the MIDI files themselves as a sample pack.

The full kits (hundreds more patterns): https://midiroad.com
Free beat maker: https://midiroad.com/beat-maker
